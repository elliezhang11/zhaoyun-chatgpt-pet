# 云珩 · ChatGPT 桌面宠物

解压后，双击 `Install-Yunheng.url`。登录 ChatGPT 后，在分享页面领养云珩，再在 ChatGPT 的桌面宠物设置中启用它。

也可以直接打开 [云珩的领养页面](https://chatgpt.com/s/sharepet_6b055ea11ac88191a2a803f82678ef0f)。

`Yunheng-Spritesheet.png` 是云珩的透明动画素材，`Preview.gif` 展示九种动作。

# Yunheng · ChatGPT desktop pet

Extract the ZIP and open `Install-Yunheng.url`. Sign in to ChatGPT, adopt Yunheng from the shared pet page, and select it in your ChatGPT desktop pet settings.
